package StepDefinitions;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Download {
	
	WebDriver driver;
	@Test
	 @Given("^user needs tobeon the home page$")
	    public void user_needs_tobeon_the_home_page() throws InterruptedException {
		 System.setProperty("webdriver.chrome.driver","C:\\Users\\Admin\\eclipse-workspace\\SeleniumDemoProject\\drivers\\chromedriver.exe" );
			driver = new ChromeDriver();
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
			driver.get("https://www.makemytrip.com/");
			/*Thread.sleep(3000);
			driver.switchTo().frame(driver.findElement(By.xpath("//iframe[@id='webklipper-publisher-widget-container-notification-frame']")));
			driver.findElement(By.xpath("//a[@id='webklipper-publisher-widget-container-notification-close-div']")).click();
			driver.switchTo().defaultContent();*/
			driver.findElement(By.xpath("//span[@class='chNavIcon appendBottom2 chSprite chFlights active']")).click();
			 JavascriptExecutor js = (JavascriptExecutor) driver;
		    	js.executeScript("arguments[0].scrollIntoView();", driver.findElement(By.xpath("//input[@placeholder='Enter Mobile number ']")));

		 
	 }
	 
	 
	@Test

    @And("^enter the mobile number$")
    public void enter_the_mobile_number() throws Throwable {
		 driver.findElement(By.xpath("//input[@placeholder='Enter Mobile number ']")).sendKeys("8317581330");
		 Thread.sleep(2000);

		 
	 }
	
	@Test
	 @And("^click on get link$")
	    public void click_on_get_link() {
		 driver.findElement(By.xpath("//button[@class='getAppLinkBtn'][text()='Get App Link']")).click();
	 }
	 
	@Test
	    @Then("^link sent successfully has to be displayed$")
	    public void link_sent_successfully_has_to_be_displayed() throws IOException {
	    	
	    	System.out.println(driver.findElement(By.xpath("//p[text()='Link sent successfully to']")).getText());
	    	String expectedURL = "https://www.makemytrip.com/flights/";
	    	String actualURL = driver.getCurrentUrl();
	    	boolean status = actualURL.contains(expectedURL);
	    	Assert.assertEquals(status, true);
	    	Screenshot.takescreenshot(driver, "Download App");
	    }

}
