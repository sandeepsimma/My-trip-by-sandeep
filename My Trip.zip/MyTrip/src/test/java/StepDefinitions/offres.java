package StepDefinitions;

import java.io.IOException;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class offres {
WebDriver driver;
	
@Test
	@Given("^user need to be onthe home page$")
    public void user_need_to_be_onthe_home_page() throws InterruptedException  {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\Admin\\eclipse-workspace\\SeleniumDemoProject\\drivers\\chromedriver.exe" );
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		driver.get("https://www.makemytrip.com/");
		/*Thread.sleep(3000);
		driver.switchTo().frame(driver.findElement(By.xpath("//iframe[@id='webklipper-publisher-widget-container-notification-frame']")));
		driver.findElement(By.xpath("//a[@id='webklipper-publisher-widget-container-notification-close-div']")).click();
		driver.switchTo().defaultContent();*/
		driver.findElement(By.xpath("//span[@class='chNavIcon appendBottom2 chSprite chFlights active']")).click();

		//driver.findElement(By.xpath("//span[@class='langCardClose']")).click();
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
    	js.executeScript("arguments[0].scrollIntoView();", driver.findElement(By.xpath("//a[@id='superOffersTab_FLIGHTS']")));
    	Thread.sleep(2000);
        

	}
@Test
	 @When("^click on the bank offers$")
	    public void click_on_the_bank_offers() {
		 //driver.findElement(By.xpath("//div[@id='Offers_Listing']")).click();
		 driver.findElement(By.xpath("//p[text()='LIVE NOW:']")).click();
		
	 }
@Test
	 @And("^select one of the offer and view details$")
	    public void select_one_of_the_offer_and_view_details()  {
	    //driver.findElement(By.xpath("//p[text()='Grab FLAT 15% Instant Discount* on Domestic Flight...']")).click();
	    Set<String> windows = driver.getWindowHandles();
	    Iterator<String>it = windows.iterator();
	    String parentId = it.next();
	    String childId = it.next();
	    driver.switchTo().window(childId);
	    
 
	 }
@Test
	 @Then("^get the promo code in the console$")
	    public void get_the_promo_code_in_the_console() throws InterruptedException, IOException {

			JavascriptExecutor js = (JavascriptExecutor) driver;
	    	js.executeScript("arguments[0].scrollIntoView();", driver.findElement(By.xpath("//span[text()='MMTAMEXINT']")));
	    	Thread.sleep(2000);
	        
		 driver.findElement(By.xpath("//span[text()='MMTAMEXINT']")).getText();
		
		 
		 String expectedURL = "https://www.makemytrip.com/promos/ih-amex-01042022.html?detail_image=no";
	    	String actualURL = driver.getCurrentUrl();
	    	boolean status = actualURL.contains(expectedURL);
	    	Assert.assertEquals(status, true);
	    	 Screenshot.takescreenshot(driver, "summer offer");
	 }

}



