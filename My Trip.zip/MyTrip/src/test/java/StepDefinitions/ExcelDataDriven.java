package StepDefinitions;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.Assert;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class ExcelDataDriven {
WebDriver driver;
	
	@Given("^i want to land on home page$")
    public void i_want_to_land_on_home_page()  {
	System.setProperty("webdriver.chrome.driver","C:\\Users\\Admin\\eclipse-workspace\\SeleniumDemoProject\\drivers\\chromedriver.exe" );
	ChromeOptions options = new ChromeOptions();
	options.addArguments("disable-notifications");
    driver = new ChromeDriver(options);
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
	driver.get("https://www.spicejet.com/");
	}
	/*driver.findElement(By.xpath("//div[text()='Login']")).click();
	driver.findElement(By.xpath("//div[text()='Email']")).click();
	driver.findElement(By.xpath("//input[@type='email']")).sendKeys("simmasandeep1511@gmail.com");
	driver.findElement(By.xpath("//input[@type='password']")).sendKeys("Ss@151199");
	driver.findElement(By.xpath("//div[@data-testid='login-cta']")).click();
	Thread.sleep(45000);*/
	//driver.findElement(By.xpath("(//input[@class='css-1cwyjr8 r-homxoj r-ubezar r-10paoce r-13qz1uu'])[1]")).sendKeys("Hyderabad");
	//driver.findElement(By.xpath("//div[text()='Bengaluru']")).click();

    @When("^enter the details$")
    public void enter_the_details() throws InterruptedException, IOException {
	driver.findElement(By.xpath("(//input[@class='css-1cwyjr8 r-homxoj r-ubezar r-10paoce r-13qz1uu'])[2]")).sendKeys("Bengaluru");
	driver.findElement(By.xpath("//div[@class='css-1dbjc4n r-1awozwy r-19m6qjp r-156aje7 r-y47klf r-1phboty r-1d6rzhh r-1pi2tsx r-1777fci r-13qz1uu']")).click();
    driver.findElement(By.xpath("//div[text()='Passengers']")).click();
    driver.findElement(By.xpath("//div[@data-testid='Adult-testID-plus-one-cta']")).click();
    driver.findElement(By.xpath("//div[@data-testid='Children-testID-plus-one-cta']")).click();
    Screenshot.takescreenshot(driver, "Excel details");
    driver.findElement(By.xpath("//div[@class='css-1dbjc4n r-1awozwy r-19m6qjp r-z2wwpe r-1loqt21 r-18u37iz r-1777fci r-d9fdf6 r-1w50u8q r-ah5dr5 r-1otgn73']")).click();
  
    driver.findElement(By.xpath("//div[@class='css-1dbjc4n r-1awozwy r-z2wwpe r-1loqt21 r-18u37iz r-1777fci r-1g94qm0 r-d9fdf6 r-1w50u8q r-ah5dr5 r-1otgn73']")).click();
  
    driver.findElement(By.xpath("(//div[@data-testid='continue-search-page-cta'])[2]")).click();
    Thread.sleep(3000);   
    }
    @And("^fetch the data from excell$")
    public void fetch_the_data_from_excell() throws Throwable {
    	FileInputStream fs= new FileInputStream("C:\\Users\\Admin\\Documents\\trip details.xlsx");
		XSSFWorkbook wb = new XSSFWorkbook(fs);
		XSSFSheet sheet = wb.getSheetAt(0);
		Row row = sheet.getRow(0);
		Cell cell = row.getCell(0);
	 String s1 = sheet.getRow(0).getCell(0).toString();
    driver.findElement(By.xpath("(//input[@class='css-1cwyjr8 r-homxoj r-poiln3 r-ubezar r-1eimq0t r-1e081e0 r-xfkzu9 r-lnhwgy'])[1]")).sendKeys(s1);
    String s2 = sheet.getRow(0).getCell(1).toString();
    driver.findElement(By.xpath("//Input[@data-testid='last-inputbox-contact-details']")).sendKeys(s2);
    String s3 = sheet.getRow(0).getCell(2).toString();
    driver.findElement(By.xpath("(//Input[@class='css-1cwyjr8 r-1yadl64 r-homxoj r-poiln3 r-ubezar r-1eimq0t r-1e081e0 r-xfkzu9 r-lnhwgy'])[1]")).sendKeys(s3);
    String s4 = sheet.getRow(0).getCell(3).toString();
    driver.findElement(By.xpath("(//Input[@class='css-1cwyjr8 r-homxoj r-poiln3 r-ubezar r-1eimq0t r-1e081e0 r-xfkzu9 r-lnhwgy'])[3]")).sendKeys(s4);
    String s5 = sheet.getRow(0).getCell(4).toString();
    driver.findElement(By.xpath("//Input[@data-testid='city-inputbox-contact-details']")).sendKeys(s5);
    Screenshot.takescreenshot(driver, "Excel contact details");
    String s6 = sheet.getRow(0).getCell(5).toString();
    driver.findElement(By.xpath("//input[@data-testid='traveller-0-first-traveller-info-input-box']")).sendKeys(s6);
    String s7 = sheet.getRow(0).getCell(6).toString();
    driver.findElement(By.xpath("//input[@data-testid='traveller-0-last-traveller-info-input-box']")).sendKeys(s7);
    String s8 = sheet.getRow(0).getCell(7).toString();
    driver.findElement(By.xpath("//input[@data-testid='sc-member-mobile-number-input-box']")).sendKeys(s8);
    Screenshot.takescreenshot(driver, "Excel first passenger");
   
    driver.findElement(By.xpath("//div[@class='css-1dbjc4n r-19m6qjp r-z2wwpe r-1loqt21 r-156q2ks r-1sp51qo r-d9fdf6 r-1otgn73 r-eafdt9 r-1i6wzkk r-lrvibr']")).click();
    
    
    String s9 = sheet.getRow(0).getCell(8).toString();
    driver.findElement(By.xpath("//input[@data-testid='traveller-1-first-traveller-info-input-box']")).sendKeys(s9);
    String s10 = sheet.getRow(0).getCell(9).toString();
    driver.findElement(By.xpath("//input[@data-testid='traveller-1-last-traveller-info-input-box']")).sendKeys(s10);
    String s11 = sheet.getRow(0).getCell(10).toString();
    driver.findElement(By.xpath("//input[@data-testid='sc-member-mobile-number-input-box']")).sendKeys(s11);
    Screenshot.takescreenshot(driver, "Excel second passenger");
   
    driver.findElement(By.xpath("//div[@data-testid='traveller-1-travel-info-cta']")).click();
    
    driver.findElement(By.xpath("//div[text()='Select']")).click();
    driver.findElement(By.xpath("//div[text()='Master']")).click();
    String s12 = sheet.getRow(0).getCell(11).toString();
    driver.findElement(By.xpath("//input[@data-testid='traveller-2-first-traveller-info-input-box']")).sendKeys(s12);
    String s13 = sheet.getRow(0).getCell(12).toString();
    driver.findElement(By.xpath("//input[@data-testid='traveller-2-last-traveller-info-input-box']")).sendKeys(s13);
    Screenshot.takescreenshot(driver, "Excel child details");
    }
    @Then("^validate with url$")
    public void validate_with_url() throws InterruptedException, IOException  {
    driver.findElement(By.xpath("//div[@data-testid='traveller-info-continue-cta']")).click();
    Thread.sleep(10000);
    String expectedURL = "https://www.spicejet.com/booking/addons";
	String actualURL = driver.getCurrentUrl();
	boolean status = actualURL.contains(expectedURL);
	Assert.assertEquals(status, true);
	 Screenshot.takescreenshot(driver, "Excel booking page");
  
}



}
