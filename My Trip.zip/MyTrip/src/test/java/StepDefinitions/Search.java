package StepDefinitions;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Search {
	
WebDriver driver;
@Test
	@Given("^user needs to be on the homepage$")
    public void user_needs_to_be_on_the_homepage() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\Admin\\eclipse-workspace\\SeleniumDemoProject\\drivers\\chromedriver.exe" );
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		driver.get("https://www.makemytrip.com/");
		//Thread.sleep(3000);
		//driver.switchTo().frame(driver.findElement(By.xpath("//iframe[@id='webklipper-publisher-widget-container-notification-frame']")));
		//driver.findElement(By.xpath("//a[@id='webklipper-publisher-widget-container-notification-close-div']")).click();
		//driver.switchTo().defaultContent();
		driver.findElement(By.xpath("//span[@class='chNavIcon appendBottom2 chSprite chFlights active']")).click();


		
	}
@Test
	@When("^enter the departure and destination places$")
    public void enter_the_departure_and_destination_places()  {
		
		
		driver.findElement(By.xpath("//label[@for='fromCity']")).click();
		driver.findElement(By.xpath("//input[@placeholder='From']")).sendKeys("Hyderabad");
		driver.findElement(By.xpath("//div[text()='HYD']")).click();
		driver.findElement(By.xpath("//span[text()='To']")).click();
		driver.findElement(By.xpath("//input[@placeholder='To']")).sendKeys("Bengaluru");
		driver.findElement(By.xpath("//div[text()='BLR']")).click();
		
	}
@Test
	 @And("^enter departure date$")
	    public void enter_departure_date() {
		 driver.findElement(By.xpath("//span[text()='DEPARTURE']")).click();
		 driver.findElement(By.xpath("//div[@aria-label='Fri May 13 2022']")).click();
		
		 		
	 }
	 
	 @And("^enter number of travellers$")
	    public void enter_number_of_travellers() {
		 driver.findElement(By.xpath("//span[@class='lbl_input latoBold appendBottom5']")).click();
		 driver.findElement(By.xpath("//li[@data-cy='adults-2']")).click();
		 driver.findElement(By.xpath("//li[text()='Economy/Premium Economy']")).click();
		 driver.findElement(By.xpath("//button[text()='APPLY']")).click();
		 

		 
	 }
	 
	 @Test
	 @And("^select the fair type$")
	    public void select_the_fair_type() throws IOException  {
		 driver.findElement(By.xpath("//p[text()='Student ']")).click();
		 Screenshot.takescreenshot(driver, "search details");
		 
	 }
	 @Test
	 @Then("^click on search flights$")
	    public void click_on_search_flights() throws IOException {
		 driver.findElement(By.xpath("//a[text()='Search']")).click();
		 //driver.findElement(By.xpath("//button[text()='OKAY, GOT IT!']")).click();
		 String expected = "MakeMyTrip";
	    	String actual = driver.getTitle();
	    	boolean status = actual.contains(expected);
	    	Assert.assertEquals(status, true);
	    	Screenshot.takescreenshot(driver, "search booking");
		 
		 
	 }

}





