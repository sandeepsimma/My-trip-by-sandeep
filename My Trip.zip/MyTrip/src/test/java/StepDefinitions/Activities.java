package StepDefinitions;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Activities {
	
WebDriver driver;
	@Test
	@Given("^user needs to be on the home page$")
    public void user_needs_to_be_on_the_home_page() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\Admin\\eclipse-workspace\\SeleniumDemoProject\\drivers\\chromedriver.exe" );
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		driver.get("https://www.makemytrip.com/");
		/*Thread.sleep(3000);
		driver.switchTo().frame(driver.findElement(By.xpath("//iframe[@id='webklipper-publisher-widget-container-notification-frame']")));
		driver.findElement(By.xpath("//a[@id='webklipper-publisher-widget-container-notification-close-div']")).click();
		driver.switchTo().defaultContent();*/
		driver.findElement(By.xpath("//span[@class='chNavIcon appendBottom2 chSprite chFlights active']")).click();

	}
	@Test
	 @When("^click on the Activities$")
	    public void click_on_the_Activities() {
		 driver.findElement(By.xpath("//span[text()='Activities']")).click();
			


		


		 
	 }
	 
	@Test
	    @And("^enter the destination$")
	    public void enter_the_destination() throws IOException {
	    	driver.findElement(By.xpath("//input[@id='activitySearch']")).click();
	    	driver.findElement(By.xpath("//input[@aria-controls='react-autowhatever-1']")).sendKeys("Goa");
	    	driver.findElement(By.xpath("//p[text()='Scuba Diving at Chivla Beach, ']")).click();
	    	Screenshot.takescreenshot(driver, "Activities details");
	    	
	    	
	    	
	    }
	@Test
	    @And("^select scuba diving$")
	    public void select_scuba_diving() {
	    	driver.findElement(By.xpath("//button[@data-cy='submit']")).click();
	    }
	@Test
	    @Then("^Package has to be displayed$")
	    public void package_has_to_be_displayed() throws IOException {
	    	driver.findElement(By.xpath("//button[text()='SELECT PACKAGE']")).click();
	    	String expected = "MakeMyTrip";
	    	String actual = driver.getTitle();
	    	boolean status = actual.contains(expected);
	    	Assert.assertEquals(status, true);
	    	Screenshot.takescreenshot(driver, "Activities Booking page");
	    }

}




