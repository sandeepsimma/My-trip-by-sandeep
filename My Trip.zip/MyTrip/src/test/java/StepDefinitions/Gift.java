package StepDefinitions;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Gift {
	
	WebDriver driver;
	@Test
	 @Given("^userneeded to be on the home page$")
	    public void userneeded_to_be_on_the_home_page() throws InterruptedException {
		 System.setProperty("webdriver.chrome.driver","C:\\Users\\Admin\\eclipse-workspace\\SeleniumDemoProject\\drivers\\chromedriver.exe" );
			driver = new ChromeDriver();
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
			driver.get("https://www.makemytrip.com/");
			//Thread.sleep(3000);
			//driver.switchTo().frame(driver.findElement(By.xpath("//iframe[@id='webklipper-publisher-widget-container-notification-frame']")));
			//driver.findElement(By.xpath("//a[@id='webklipper-publisher-widget-container-notification-close-div']")).click();
			//driver.switchTo().defaultContent();
			driver.findElement(By.xpath("//span[@class='chNavIcon appendBottom2 chSprite chFlights active']")).click();


	 }
	@Test
	 @When("^click on gift cards$")
	    public void click_on_gift_cards() throws InterruptedException {
		 JavascriptExecutor js = (JavascriptExecutor) driver;
	    	js.executeScript("arguments[0].scrollIntoView();", driver.findElement(By.xpath("//span[text()='Gift Cards']")));
		 driver.findElement(By.xpath("//span[text()='Gift Cards']")).click();
		 Set<String> windows = driver.getWindowHandles();
		 Iterator<String> itr = windows.iterator();
		 String fwindow = itr.next();
		 String swindow = itr.next();
		 driver.switchTo().window(swindow);
		 
		 //JavascriptExecutor js = (JavascriptExecutor) driver;
	    	js.executeScript("arguments[0].scrollIntoView();", driver.findElement(By.xpath("//p[text()='Rakshabandhan Gift Card']")));
	    	Thread.sleep(2000);
		 
		
		 
		 
	 }
	 
	@Test
	    @And("^select birthday gift card$")
	    public void select_birthday_gift_card() {
	    	 
			 
			 driver.findElement(By.xpath("//p[text()='Rakshabandhan Gift Card']")).click();

	    	
	    }
	@Test
	    @And("^click on buy now$")
	    public void click_on_buy_now()  {
	    	driver.findElement(By.xpath("//button[text()='BUY NOW']")).click();
	    }
	@Test
	    @Then("^payment page has to be displayed$")
	    public void payment_page_has_to_be_displayed() throws IOException {
	    	String expectedURL = "https://www.makemytrip.com/gift-cards/details/?gcid=53";
	    	String actualURL = driver.getCurrentUrl();
	    	boolean status = actualURL.contains(expectedURL);
	    	Assert.assertEquals(status, true);
	    	Screenshot.takescreenshot(driver, "Gift card");

	    }

}
