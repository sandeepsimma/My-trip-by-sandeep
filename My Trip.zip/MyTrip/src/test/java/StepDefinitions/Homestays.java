package StepDefinitions;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Homestays {
	
WebDriver driver;
@Test
	@Given("^user needs to be on home page$")
    public void user_needs_to_be_on_home_page() throws InterruptedException  {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\Admin\\eclipse-workspace\\SeleniumDemoProject\\drivers\\chromedriver.exe" );
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		driver.get("https://www.makemytrip.com/");
		/*Thread.sleep(3000);
		driver.switchTo().frame(driver.findElement(By.xpath("//iframe[@id='webklipper-publisher-widget-container-notification-frame']")));
		driver.findElement(By.xpath("//a[@id='webklipper-publisher-widget-container-notification-close-div']")).click();
		driver.switchTo().defaultContent();*/
		driver.findElement(By.xpath("//span[@class='chNavIcon appendBottom2 chSprite chFlights active']")).click();
	}

@Test
	 @When("^click on hotels$")
	    public void click_on_hotels() {
			driver.findElement(By.xpath("//span[@class='chNavIcon appendBottom2 chSprite chHomestays']")).click();

	 }

@Test
	 
	 @And("^enter the area$")
	    public void enter_the_area() {
		 driver.findElement(By.xpath("//span[text()='City / Hotel / Area / Building']")).click();
			driver.findElement(By.xpath("//input[@placeholder='Enter city/ Hotel/ Area/ Building']")).sendKeys("Goa");
			driver.findElement(By.xpath("//p[text()='South Goa, Goa']")).click();
	 }

@Test
	  @And("^enter the check in and chech out dates$")
	    public void enter_the_check_in_and_chech_out_dates() {
		  driver.findElement(By.xpath("//input[@id='checkin']")).click();
			driver.findElement(By.xpath("//div[@aria-label='Fri May 20 2022']")).click();
			driver.findElement(By.xpath("//input[@id='checkout']")).click();
			driver.findElement(By.xpath("//div[@aria-label='Tue May 24 2022']")).click();
	  }
@Test
	  @And("^enter the number of rooms and guests$")
	    public void enter_the_number_of_rooms_and_guests() throws InterruptedException, IOException  {
		  driver.findElement(By.xpath("//input[@id='guest']")).click();
			driver.findElement(By.xpath("//li[@data-cy='adults-4']")).click();
			driver.findElement(By.xpath("//button[@data-cy='submitGuest']")).click();
			Screenshot.takescreenshot(driver, "Homestay details");
			driver.findElement(By.xpath("//button[@id='hsw_search_button']")).click();
		    


	  }
@Test
	  @And("^add some filters like price and property type$")
	    public void add_some_filters_like_price_and_property_type() throws IOException {
			driver.findElement(By.xpath("//p[text()='Select Trip Type']")).click();
			driver.findElement(By.xpath("//li[text()='Family']")).click();
			driver.findElement(By.xpath("//span[text()='Popularity']")).click();
			driver.findElement(By.xpath("//li[text()='Price - Low to High']")).click();
			Screenshot.takescreenshot(driver, "Homestay filters");

	  }
@Test
	  @Then("^all the hotels should be displayed$")
	    public void all_the_hotels_should_be_displayed() throws IOException {
		  Screenshot.takescreenshot(driver, "Home Stays");
		  String expected = "MakeMyTrip";
	    	String actual = driver.getTitle();
	    	boolean status = actual.contains(expected);
	    	Assert.assertEquals(status, true);
	    	
	    }



}
