package StepDefinitions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.Assert;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Outline {
	WebDriver driver;
	
	  @Given("^user needed to be login in to the Website$")
	    public void user_needed_to_be_login_in_to_the_website() throws Throwable {
		  System.setProperty("webdriver.chrome.driver","C:\\Users\\Admin\\eclipse-workspace\\SeleniumDemoProject\\drivers\\chromedriver.exe" );
			ChromeOptions options = new ChromeOptions();
			options.addArguments("disable-notifications");
		    driver = new ChromeDriver(options);
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
			driver.get("https://www.spicejet.com/");
			
	  }
	  

	    @When("^Enter the details like destination date and number of persons$")
	    public void enter_the_details_like_destination_date_and_number_of_persons() throws Throwable {
	    	driver.findElement(By.xpath("(//input[@class='css-1cwyjr8 r-homxoj r-ubezar r-10paoce r-13qz1uu'])[2]")).sendKeys("Bengaluru");
	    	driver.findElement(By.xpath("//div[@class='css-1dbjc4n r-1awozwy r-19m6qjp r-156aje7 r-y47klf r-1phboty r-1d6rzhh r-1pi2tsx r-1777fci r-13qz1uu']")).click();
	        driver.findElement(By.xpath("//div[text()='Passengers']")).click();
	        driver.findElement(By.xpath("//div[@data-testid='Adult-testID-plus-one-cta']")).click();
	        driver.findElement(By.xpath("//div[@data-testid='Children-testID-plus-one-cta']")).click();
	        driver.findElement(By.xpath("//div[@class='css-1dbjc4n r-1awozwy r-19m6qjp r-z2wwpe r-1loqt21 r-18u37iz r-1777fci r-d9fdf6 r-1w50u8q r-ah5dr5 r-1otgn73']")).click();
	        Screenshot.takescreenshot(driver, "Outline details");

	        
	    }
	    

	    @And("^select the flight$")
	    public void select_the_flight() throws Throwable {
	    	 driver.findElement(By.xpath("//div[@class='css-1dbjc4n r-1awozwy r-z2wwpe r-1loqt21 r-18u37iz r-1777fci r-1g94qm0 r-d9fdf6 r-1w50u8q r-ah5dr5 r-1otgn73']")).click();
		     driver.findElement(By.xpath("(//div[@data-testid='continue-search-page-cta'])[2]")).click();
		     Thread.sleep(3000);   

	    	
	    	
	    }
	    

	    @And("^ENTER the \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	    public void enter_the_FIRSTname_and_LASTname_and_contact_and_email_and_city(String FIRSTname, String LASTname, String contact, String email, String city) throws Throwable {
	    	    driver.findElement(By.xpath("(//input[@class='css-1cwyjr8 r-homxoj r-poiln3 r-ubezar r-1eimq0t r-1e081e0 r-xfkzu9 r-lnhwgy'])[1]")).sendKeys(FIRSTname);
	    	    driver.findElement(By.xpath("//Input[@data-testid='last-inputbox-contact-details']")).sendKeys(LASTname);
	    	    driver.findElement(By.xpath("(//Input[@class='css-1cwyjr8 r-1yadl64 r-homxoj r-poiln3 r-ubezar r-1eimq0t r-1e081e0 r-xfkzu9 r-lnhwgy'])[1]")).sendKeys(contact);
	    	    driver.findElement(By.xpath("(//Input[@class='css-1cwyjr8 r-homxoj r-poiln3 r-ubezar r-1eimq0t r-1e081e0 r-xfkzu9 r-lnhwgy'])[3]")).sendKeys(email);
	    	    driver.findElement(By.xpath("//Input[@data-testid='city-inputbox-contact-details']")).sendKeys(city);
	    	    Screenshot.takescreenshot(driver, "Outline details");
	        
	    }
	    @And("^enter the \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	    public void enter_the_firstname_and_lastname_and_phonenumber(String firstname, String lastname, String phonenumber) throws Throwable {
	        driver.findElement(By.xpath("//input[@data-testid='traveller-0-first-traveller-info-input-box']")).sendKeys(firstname);
	        driver.findElement(By.xpath("//input[@data-testid='traveller-0-last-traveller-info-input-box']")).sendKeys(lastname);
	        driver.findElement(By.xpath("//input[@data-testid='sc-member-mobile-number-input-box']")).sendKeys(phonenumber);
	        driver.findElement(By.xpath("//div[@class='css-1dbjc4n r-19m6qjp r-z2wwpe r-1loqt21 r-156q2ks r-1sp51qo r-d9fdf6 r-1otgn73 r-eafdt9 r-1i6wzkk r-lrvibr']")).click();
	        Screenshot.takescreenshot(driver, "Outline first passenger");
	    	
	    }
	    
	    @And("^Enter \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	    public void enter_FirstName_and_LastName_and_PhoneNumber(String FirstName, String LastName, String PhoneNumber) throws Throwable {
	    driver.findElement(By.xpath("//input[@data-testid='traveller-1-first-traveller-info-input-box']")).sendKeys(FirstName);
	    driver.findElement(By.xpath("//input[@data-testid='traveller-1-last-traveller-info-input-box']")).sendKeys(LastName);
	    driver.findElement(By.xpath("//input[@data-testid='sc-member-mobile-number-input-box']")).sendKeys(PhoneNumber);
	    driver.findElement(By.xpath("//div[@data-testid='traveller-1-travel-info-cta']")).click();
	    Screenshot.takescreenshot(driver, "Outline second passenger");
}
	    
	    
	    @And("^Enter the \"([^\"]*)\" and \"([^\"]*)\"$")
	    public void enter_the_FIRSTNAME_and_LASTNAME(String FIRSTNAME, String LASTNAME) throws Throwable {
	        driver.findElement(By.xpath("//div[text()='Select']")).click();
	        driver.findElement(By.xpath("//div[text()='Master']")).click();
	    	driver.findElement(By.xpath("//input[@data-testid='traveller-2-first-traveller-info-input-box']")).sendKeys(FIRSTNAME);
	    	driver.findElement(By.xpath("//input[@data-testid='traveller-2-last-traveller-info-input-box']")).sendKeys(LASTNAME);
	    	Screenshot.takescreenshot(driver, "Outline Third Passenger");
	    	driver.findElement(By.xpath("//div[@data-testid='traveller-info-continue-cta']")).click();
	    	   
    	    
    	    
    	   
	    }
	    
	    
	    @Then("^proceed with booking$")
	    public void proceed_with_booking() throws Throwable {
	    	Thread.sleep(10000);
	    	String expectedURL = "https://www.spicejet.com/booking/addons";
	    	String actualURL = driver.getCurrentUrl();
	    	boolean status = actualURL.contains(expectedURL);
	    	Assert.assertEquals(status, true);
	    	Screenshot.takescreenshot(driver, "Outline Booking page ");

		    	
	    	
	    }
	       
	       
	

}
