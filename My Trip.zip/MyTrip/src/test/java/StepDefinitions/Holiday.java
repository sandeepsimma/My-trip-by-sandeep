package StepDefinitions;

import java.io.IOException;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Holiday {
	WebDriver driver;
	
	@Test
	 @Given("^user needs to be on thehomepage$")
	    public void user_needs_to_be_on_thehomepage() throws InterruptedException {
		 System.setProperty("webdriver.chrome.driver","C:\\Users\\Admin\\eclipse-workspace\\SeleniumDemoProject\\drivers\\chromedriver.exe" );
			driver = new ChromeDriver();
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
			driver.get("https://www.makemytrip.com/");
			/*Thread.sleep(3000);
			driver.switchTo().frame(driver.findElement(By.xpath("//iframe[@id='webklipper-publisher-widget-container-notification-frame']")));
			driver.findElement(By.xpath("//a[@id='webklipper-publisher-widget-container-notification-close-div']")).click();
			driver.switchTo().defaultContent();*/
			driver.findElement(By.xpath("//span[@class='chNavIcon appendBottom2 chSprite chFlights active']")).click();

		 
	 }
	@Test
	 @When("^click on the holiday packages$")
	    public void click_on_the_holiday_packages() {
		 driver.findElement(By.xpath("//span[text()='Holiday Packages']")).click();
		 
	 }
	@Test
	 @And("^enter the destination city and search$")
	    public void enter_the_destination_city_and_search() throws InterruptedException, IOException  {
		//driver.findElement(By.xpath("//span[@class='chNavIcon appendBottom2 chSprite chFlights active']")).click();
		 //driver.findElement(By.xpath("//span[text()='Holiday Packages']")).click();
		driver.findElement(By.xpath("//span[text()='Super Deals']")).click();
		driver.findElement(By.xpath("//li[text()='Summer Special']")).click();
		driver.findElement(By.xpath("//a[text()='Ladakh']")).click();
		Screenshot.takescreenshot(driver, "Holiday details");
		 
		 
		 
	 }
	@Test
	 @And("^select the budget and duration$")
	    public void select_the_budget_and_duration() {
		
		Set<String> windows = driver.getWindowHandles();
		 Iterator<String> itr = windows.iterator();
		 String fwindow = itr.next();
		 String swindow = itr.next();
		 driver.switchTo().window(swindow);
	     driver.findElement(By.xpath("//button[text()='SKIP']")).click();
		
	 }
	 
	@Test
	    @And("^select the hotel catogery and prices$")
	    public void select_the_hotel_catogery_and_prices() throws IOException  {
		
		 driver.findElement(By.xpath("//li[text()='3']")).click();
		 driver.findElement(By.xpath("//div[text()='Popular']")).click();
		 driver.findElement(By.xpath("//div[text()='Price - Low to High']")).click();
		 Screenshot.takescreenshot(driver, "Holiday filters");
	    	
	    }
	@Test
	 @Then("^select the first hotel it is showing$")
	    public void select_the_first_hotel_it_is_showing() throws IOException {
		
		 String expectedURL = "https://holidayz.makemytrip.com/holidays/international/search?dest=Ladakh&redirectionPage=grouping";
	    	String actualURL = driver.getCurrentUrl();
	    	boolean status = actualURL.contains(expectedURL);
	    	Assert.assertEquals(status, true);
	    	Screenshot.takescreenshot(driver, "Holidays");

		 
	 }

}
