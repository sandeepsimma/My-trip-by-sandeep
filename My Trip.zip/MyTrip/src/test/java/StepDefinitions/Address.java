package StepDefinitions;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Address {
	
	WebDriver driver;
	@Test
	@Given("^user needed to be on the home page$")
    public void user_needed_to_be_on_the_home_page() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\Admin\\eclipse-workspace\\SeleniumDemoProject\\drivers\\chromedriver.exe" );
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		driver.get("https://www.makemytrip.com/support/in/branch-offices.php#h");
		
		
	
	}
	@Test
	 @When("^navigate to careers page$")
	    public void navigate_to_careers_page() throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) driver;
    	js.executeScript("arguments[0].scrollIntoView();", driver.findElement(By.xpath("//option[text()='Select City']")));


		 
	 }
	 
	@Test
	    @And("^enter the details and location$")
	    public void enter_the_details_and_location() {
		driver.findElement(By.xpath("//option[text()='Select City']")).click();
		driver.findElement(By.xpath("//option[text()='Hyderabad (Kondapur)']")).click();

	    	
	    }
	@Test
	    @Then("^all the jobs has to be displayed$")
	    public void all_the_jobs_has_to_be_displayed() throws IOException {
		
		
		String expectedurl = "https://www.makemytrip.com/support/in/branch-offices.php#h";
    	String actualurl = driver.getCurrentUrl();
    	boolean status = actualurl.contains(expectedurl);
    	Assert.assertEquals(status, true);
	    	
	    	Screenshot.takescreenshot(driver, "Address");
	    	
	    }


}
