package Runner;

import org.testng.annotations.Listeners;

import com.aventstack.extentreports.testng.listener.ExtentITestListenerClassAdapter;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

	
@CucumberOptions (
		plugin= {"pretty",
				"html:target/mytrip-reports/cucumber.html",
				"json:target/mytrip-reports/cucumber.json",},
		
		features = {"src//test//java//Features"},
		glue = {"StepDefinitions"}
		
		)


@Listeners({ExtentITestListenerClassAdapter.class})


public class Total_scenarios extends AbstractTestNGCucumberTests {

}
